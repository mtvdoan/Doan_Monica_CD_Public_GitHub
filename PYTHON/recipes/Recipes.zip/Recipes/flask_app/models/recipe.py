# import the function that will return an instance of a connection
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import app
from flask_bcrypt import Bcrypt
from flask_app.models import reglog
import re
db = "reglog-User_to_Recipes"

class Recipe:
    def __init__(self,recipe):
        self.id = recipe['id']
        self.recipe_name = recipe['recipe_name']
        self.recipe_description = recipe['recipe_description']
        self.recipe_instructions = recipe['recipe_instructions']
        self.recipe_data_made = recipe['recipe_date_made']
        self.recipe_under_30 = recipe['recipe_under_30']
        self.created_at = recipe['created_at']
        self.updated_at = recipe['updated_at']
        self.reglog = None
    
    @classmethod
    def create_valid_recipe(cls, recipe_dictionary):
        if not cls.is_valid(recipe_dictionary):
            return False
    
    
    @classmethod
    def get_by_id(cls, recipe_id):
        print(f"get recipe by id {recipe_id}")
        data = {"id": recipe_id}
        
        query = """SELECT recipes.id, recipes.created_at, recipes.updated_at, recipe_instructions, recipe_description, recipe_name, recipe_date_made, recipe_under_30, 
        reglogs.id as reglog_id, first_name, last_name, email, password, reglogs.created_at as rlc, reglogs.updated_at as rlu 
                    FROM recipes 
                    JOIN reglogs on reglogs.id = recipes.reglog_id 
                    WHERE recipes.id = %(id)s;"""
        
        result = connectToMySQL(db).query_db(query,data)
        print("result of query:")
        print(result)
        result = result[0]
        recipe = cls(result)
        
        # convert joined reglog data into a reglog object
        recipe.reglog = reglog.Reglog(
                {
                    "id": result["reglog_id"],
                    "first_name": result["first_name"],
                    "last_name": result["last_name"],
                    "email": result["email"],
                    "password": result["password"],
                    "created_at": result["rlc"],
                    "updated_at": result["rlu"]
                }
            )
        return recipe
        # query = "SELECT * FROM recipes"
        # recipes_from_db = connectToMySQL(cls.db).query_db(query)
        # recipes = []
        # for row in recipes_from_db:
        #     recipes.append(cls(row))
        # return recipes
    
    @classmethod
    def get_all(cls):
        # Get all recipes, and the user info for the creators
        query ="""SELECT recipes.id, recipes.created_at, recipes.updated_at, recipe_instructions, recipe_description, recipe_name, recipe_date_made, recipe_under_30, 
                    reglogs.id as reglog_id, first_name, last_name, email, password, reglogs.created_at as rlc, reglogs.updated_at as rlu 
                    FROM recipes 
                    JOIN reglogs on reglogs.id = recipes.reglog_id;"""
        recipe_data = connectToMySQL(db).query_db(query)

        # Make a list to hold recipe objects to return
        recipes = []

        # Iterate through the list of recipe dictionaries
        for recipe in recipe_data:

            # convert data into a recipe object
            recipe_obj = cls(recipe)

            # convert joined reglog data into a reglog object
            recipe_obj.reglog = reglog.Reglog(
                {
                    "id": recipe["reglog_id"],
                    "first_name": recipe["first_name"],
                    "last_name": recipe["last_name"],
                    "email": recipe["email"],
                    "password": recipe["password"],
                    "created_at": recipe["rlc"],
                    "updated_at": recipe["rlu"]
                }
            )
            recipes.append(recipe_obj)
        return recipes
    
    
    @classmethod
    def update_recipe(cls, recipe_dictionary, session_id):

        # Authenticate User first
        recipe = cls.get_by_id(recipe_dictionary["id"])
        if recipe.reglog.id != session_id:
            flash("You must be the creator to update this recipe.")
            return False

        # Validate the input
        if not cls.is_valid(recipe_dictionary):
            return False
        
        # Update the data in the database.
        query = """UPDATE recipes
                    SET name = %(recipe_name)s, recipe_description = %(recipe_description)s, recipe_instructions = %(recipe_instructions)s, recipe_date_made=%(recipe_date_made)s, recipe_under_30 = %(recipe_under_30)s
                    WHERE id = %(id)s;"""
                    
        connectToMySQL(db).query_db(query,recipe_dictionary)
        recipe = cls.get_by_id(recipe_dictionary["id"])
        
        return recipe
    

    @classmethod
    def delete_recipe_by_id(cls, recipe_id):
        
        data = {"id": recipe_id}
        query = "DELETE FROM recipes WHERE id = %(id)s;"
        connectToMySQL(db).query_db(query, data)
        
        return recipe_id 
    
    @staticmethod
    def is_valid(recipe_dictionary):
        valid = True
        flash_string = " field is required and must be at least 3 characters."
        if len(recipe_dictionary["name"]) < 3:
            flash("Recipe Name: " + flash_string)
            valid = False
        if len(recipe_dictionary["recipe_description"]) < 3:
            flash("Recipe Description: " + flash_string)
            valid = False
        if len(recipe_dictionary["recipe_instructions"]) < 3:
            flash("Recipe Instructions: " + flash_string)
            valid = False

        if len(recipe_dictionary["recipe_date_made"]) <= 0:
            flash("Creation date required.")
            valid = False
        if "under_30" not in recipe_dictionary:
            flash("Can you make this in 30 minutes?")
            valid = False

        return valid
        