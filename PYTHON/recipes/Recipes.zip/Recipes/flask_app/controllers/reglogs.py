#CONTROLLER PYTHON FILE--------------------------------------------------------------------------------------------------------------------------------
from flask import render_template, redirect, session, request
from flask_app import app
from flask_app.models.reglog import Reglog
from flask import flash


#HOME -----------------------------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


#REGISTER------------User will enter info and click submit.  This will save all info in db and hash password at registration--------------------------------------------------------------------------------------------------------------------
@app.route('/register',methods=['POST'])
def register():
    verified_reglog = Reglog.insert_verified_reglog(request.form)
    
    if not verified_reglog:
        return redirect("/")

    session['reglog_id'] = verified_reglog.id
    
    return redirect('/recipes/wall')

#LOGIN----------This is where user logs in.  All info will be validated with the database.  flash messages are in index.html-----------------------------------------------------
@app.route('/login', methods=['POST'])
def login(): 
    real_reglog = Reglog.verified_reglog(request.form)
    if not real_reglog:
        flash("Invalid Email/Password", "login")
        return redirect("/")
    
    session["reglog_id"] = real_reglog.id
    return redirect("/recipes/wall")

@app.route("/logout")
def logout():
    session.clear()
    return redirect('/')

    
    # data = { "email" : request.form["email"] }
    # reglog_in_db = Reglog.get_by_email(data)
    
    # if not reglog_in_db:
    #     flash("Invalid Email/Password", "login")
    #     return redirect("/")
    # if not bcrypt.check_password_hash(reglog_in_db.password, request.form['password']):
    #     flash("Invalid Email/Password", "login")
    #     return redirect('/')
    # session['reglog_id'] = reglog_in_db.id
    # return redirect("/recipes")

#recipes (WELCOME PAGE POST LOGIN SUCCESS; FAIL WILL REMAIN ON SAME PAGE FLASHING ERROR MESSAGES :(----------------------------------------------------------------
# @app.route('/recipes')
# def recipes():
#     if 'reglog_id' not in session:
#         flash("")
#         return redirect('/')
#     data ={
#         'id': session['reglog_id']
#     }
#     return render_template('recipes.html', reglog=Reglog.get_by_id(data))


    

#testing below

# @app.route('/success')
# def recipes():
#     if 'reglog_id' not in session:
#         return redirect('/')
#     data ={
#         'id': session['reglog_id']
#     }
#     return render_template('success.html', reglog=Reglog.get_by_id(data))

# @app.route('/success')
# def recipes():
#     return render_template('success.html', reglog=Reglog.get_by_id(data))

#--------------------------------------------------------------------------------
